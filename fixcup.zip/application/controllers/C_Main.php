<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_Main extends CI_Controller {

    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_User','usr');
        $this->load->model('M_Main','main');

        $data = array(
			'title' => null,
			'breadcrumb' => null,
			'active' => null,
			'is_open' => false,
			'subactive' => null,
			'content' => null,
		);

		if(is_null($this->session->userdata('User'))){
			redirect('Login','refresh');
		}
    }

    public function index()
    {
    	$this->load->view('errors/html/error_404');
    }
    

    public function Home()
    {
        $data = array(
            'title' => 'Dashboard',
            'breadcrumb' => '<li class="breadcrumb-item active">Dashboard</li>',
            'active' => 'menu_dashboard',
            'is_open' => false,
        );
        $datacon = $this->main->Get_Dash();
        $data['content'] = $this->load->view('dash',$datacon, TRUE);
        $this->load->view('home',$data);
    }

    public function d_webinar()
    {
        $data = array(
            'title' => 'Data Webinar',
            'breadcrumb' => '<li class="breadcrumb-item active">Data Webinar</li>',
            'active' => 'menu_data',
            'is_open' => true,
        );
        $datacon = $this->main->get_data('webinar');
        $this->load->view('webinar',$datacon);
        // $this->load->view('', $data, FALSE);   
        // echo 'User IP - '.$_SERVER['REMOTE_ADDR'];   
    }

    public function Logout()
    {
        session_destroy();
        redirect('Home','refresh');
    }

}

/* End of file Controllername.php */
